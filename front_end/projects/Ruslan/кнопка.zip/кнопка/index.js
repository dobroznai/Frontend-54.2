// Получаем кнопку
var scrollToTopBtn = document.getElementById("scrollToTopBtn");

// Показывать кнопку при прокрутке вниз на 100px
window.onscroll = function() {
    if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
        scrollToTopBtn.style.display = "block";
    } else {
        scrollToTopBtn.style.display = "none";
    }
};

// При нажатии на кнопку возвращаемся наверх
scrollToTopBtn.addEventListener("click", function(event) {
    event.preventDefault(); // Предотвращаем переход по ссылке
    window.scrollTo({
        top: 0,
        behavior: 'smooth' // Плавный скролл
    });
});